---
name: Pine & Amber Editorial SaaS
colors:
  surface: '#f9f9f8'
  surface-dim: '#d9dad9'
  surface-bright: '#f9f9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f3'
  surface-container: '#edeeed'
  surface-container-high: '#e7e8e7'
  surface-container-highest: '#e1e3e2'
  on-surface: '#191c1c'
  on-surface-variant: '#414846'
  inverse-surface: '#2e3131'
  inverse-on-surface: '#f0f1f0'
  outline: '#717975'
  outline-variant: '#c0c8c4'
  surface-tint: '#3f665b'
  primary: '#002921'
  on-primary: '#ffffff'
  primary-container: '#173f36'
  on-primary-container: '#82aa9e'
  inverse-primary: '#a6cfc3'
  secondary: '#785a00'
  on-secondary: '#ffffff'
  secondary-container: '#ffd576'
  on-secondary-container: '#795a00'
  tertiary: '#0c2721'
  on-tertiary: '#ffffff'
  tertiary-container: '#233d36'
  on-tertiary-container: '#8ca89f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1ebde'
  primary-fixed-dim: '#a6cfc3'
  on-primary-fixed: '#00201a'
  on-primary-fixed-variant: '#274e44'
  secondary-fixed: '#ffdf9b'
  secondary-fixed-dim: '#eac165'
  on-secondary-fixed: '#251a00'
  on-secondary-fixed-variant: '#5b4300'
  tertiary-fixed: '#cbe9df'
  tertiary-fixed-dim: '#b0cdc3'
  on-tertiary-fixed: '#05201a'
  on-tertiary-fixed-variant: '#324c45'
  background: '#f9f9f8'
  on-background: '#191c1c'
  surface-variant: '#e1e3e2'
  pine-deep: '#173F36'
  pine-hover: '#1F4F44'
  pine-light: '#E9F0EE'
  amber-gold: '#F2C96C'
  amber-hover: '#E5BB5A'
  amber-surface: '#FDF8ED'
  amber-dark: '#7A5E12'
  status-present: '#C5DCD8'
  status-sick: '#E9D9A7'
  status-permission: '#C7D5E5'
  status-absent: '#E7B9B9'
  status-active: '#D9A7E8'
  canvas-base: '#F8F9F8'
  surface-card: '#FFFFFF'
  border-subtle: '#E4E8E6'
  border-control: '#D4DAD7'
  text-primary: '#111816'
  text-muted: '#6E7A76'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 72px
    fontWeight: '800'
    lineHeight: '1.0'
    letterSpacing: -0.035em
  display-hero-mobile:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '800'
    lineHeight: '1.05'
    letterSpacing: -0.025em
  headline-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.08'
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.15'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.12'
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: -0.005em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: 0em
  eyebrow:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
---

## Brand & Style

This design system translates Scandinavian editorial minimalism into an organic, dignified SaaS experience for high-trust education, operations, and community workflows. Moving away from sterile monochrome software, it infuses daily rituals with grounded maturity, warmth, and deliberate pacing.

The target audience encompasses progressive educators, institution administrators, and operations leads who manage high-stakes rosters and daily check-ins. The emotional tone evokes calm certainty, clarity, and thoughtful prestige.

The aesthetic blends **Warm Editorial SaaS** with high-craft surface modeling:
- **Deep Organic Anchor:** Built on a foundation of deep forest pine green, conveying architectural permanence and institutional trust.
- **Sunlit Highlights:** Luminous golden-amber accents highlight essential calls-to-action, time-critical alerts, and milestones without causing notification fatigue.
- **Editorial Typography:** High-contrast, tightly kerned modernist typography provides clear hierarchy and an authoritative poster-like composition.
- **Tactile Soft Volumes:** Generously rounded cards, crisp hairline borders, and subtle tinted surface tones replace rigid spreadsheet aesthetics with inviting, physical workspace cards.

## Colors

The color palette centers around a signature deep pine `#173F36` as the authoritative primary anchor, complemented by an amber accent `#F2C96C` for focal moments, high-level summaries, and verified states.

### Core Roles
- **Primary (`#173F36`)**: Defines high-priority interactive components, solid buttons, dark summary panels, selected roster items, and authoritative headings.
- **Secondary (`#F2C96C`)**: Reserved for high-value highlights, badges, completion milestones, active tabs, and secondary visual tags. When used as a surface, foreground text transitions to `#7A5E12` or deep pine `#173F36` to maintain WCAG AA compliance.
- **Tertiary (`#314B44`)**: Used for muted accents, secondary navigation states, active chips, and subtle focus states within dark containers.
- **Neutral Canvas (`#F8F9F8`)**: The primary warm off-white canvas. Standard surfaces and cards lift above this using crisp `#FFFFFF` paired with `#E4E8E6` hairline borders.

### Semantic Roster Badges
Attendance states maintain multi-channel feedback (tint, icon, and text):
- **Present (`#C5DCD8`)**: Calm seafoam mint with `#111816` text.
- **Excused / Sick (`#E9D9A7`)**: Muted bamboo cream with `#111816` text.
- **Permission (`#C7D5E5`)**: Soft slate blue with `#111816` text.
- **Absent (`#E7B9B9`)**: Gentle blush rose with `#111816` text.

## Typography

The typographic hierarchy utilizes **Inter** across all functional roles, driven by editorial proportions and tight display tracking:
- **Hero & Display:** High-impact titles deploy an `800` weight with `-0.035em` negative letter-spacing and a strict `1.0` line-height ratio, establishing an authoritative editorial anchor.
- **Section Titles:** Set between `24px` and `36px` at `600` or `700` weight to clearly demarcate daily sessions, metrics summaries, and class sections.
- **Body & Tabular Reading:** Set at `14px`–`16px` with a neutral tracking and `1.5` line height for sustained reading across long student rosters, notes, and attendance histories.
- **Eyebrow Meta:** Rendered at `12px` uppercase with `0.08em` tracking in deep pine `#173F36` or muted sage `#6E7A76` to introduce category labels above major titles.

## Layout & Spacing

The layout is built upon an **8px base grid** with a **4px half-step** for precise control alignment:

- **Desktop (≥ 1024px)**: Uses a 12-column structure with a max container width of `1240px`, `2rem` (`32px`) margins, and `1.25rem` (`20px`) gutters. Section spacing scales from `3rem` to `4.5rem` (`48px`–`72px`) for an open layout.
- **Tablet (768px – 1023px)**: 8-column layout with `1.5rem` (`24px`) margins. Roster grids and metric summary modules collapse into 2-column configurations.
- **Mobile (< 768px)**: 4-column layout with `1rem` (`16px`) side margins. Horizontal table layouts convert to vertically stacked, swipeable student summary cards.

Inner component spacing follows standard increments: compact status pills use `space-xs` and `space-sm`, form controls use `space-md`, and content card interiors use `space-lg` to `space-xl`.

## Elevation & Depth

This system uses a tactile, Scandinavian editorial layering model instead of traditional, heavy shadows:

- **Canvas Foundation:** Base canvas `#F8F9F8` creates a warm backdrop. Elevated surfaces use pure white `#FFFFFF` outlined with a subtle `1px solid #E4E8E6` border.
- **Ambient Card Depth:** Lifted elements (roster cards, interactive tiles, floating action menus) use an ambient diffused shadow: `0 8px 24px rgba(23, 63, 54, 0.05)`. The green-tinted shadow anchors cards directly into the pine color world.
- **Floating Focus & Modals:** Key modals, date pickers, and active popovers float with `0 16px 40px rgba(17, 24, 22, 0.12)` and a crisp `1px solid #D4DAD7` stroke.
- **Inverted Hero Surfaces:** Deep pine panels (`#173F36`) with white and golden amber text create high-contrast focal points for daily roll-calls and metric overviews.

## Shapes

The interface balances soft geometry with clean edges:
- **Interactive Controls (Inputs, Buttons, Dropdowns):** Rounded with a `12px` (`0.75rem`) radius to provide an approachable, tactile touch surface.
- **Surfaces & Roster Containers:** Structured with `16px` to `24px` (`1rem`–`1.5rem`) outer radii to create distinct card boundaries.
- **Pills (`9999px`):** Reserved for attendance status chips (Hadir, Sakit, Izin, Alpa), count tags, and avatar rings.
- **Checkboxes & Segment Toggles:** Use a soft `8px` (`0.5rem`) radius for quick target acquisition.

## Components

### Buttons
- **Primary Button**: Solid deep pine `#173F36` fill, `#FFFFFF` text, `44px` height, `12px` border radius, `0 20px` padding. Typography: `14px`, weight `600`. Hover state: deepens to `#1F4F44` with a subtle `-1px` transform.
- **Accent Button**: Amber `#F2C96C` background, `#173F36` text, `44px` height, `12px` radius. Used for primary CTAs like "Submit Roll Call" or "Export Roster."
- **Secondary Button**: `#FFFFFF` background, `1px solid #D4DAD7` border, `#173F36` text, `44px` height, `12px` radius. Hover state: `#F8F9F8`.
- **Ghost Button**: Transparent surface, `#173F36` text, transitioning to `#E9F0EE` background on hover.

### Chips & Attendance Pills
- Configured as pills (`border-radius: 9999px`) with `6px 14px` padding and `12px` font size (`font-weight: 500`).
- **Present**: Fill `#C5DCD8`, text `#111816`, checkmark icon (`✓`).
- **Sick**: Fill `#E9D9A7`, text `#111816`, medical cross icon (`+`).
- **Permission**: Fill `#C7D5E5`, text `#111816`, information icon (`○`).
- **Absent**: Fill `#E7B9B9`, text `#111816`, cross icon (`✕`).
- **Active Filter**: Fill `#173F36`, text `#FFFFFF`.

### Input Fields
- Height `44px`, background `#FFFFFF`, border `1px solid #D4DAD7`, `12px` radius, typography `14px`.
- Placeholder text in `#6E7A76`.
- Focus state: `1.5px solid #173F36` border with a soft `0 0 0 3px rgba(23, 63, 54, 0.1)` glow ring.

### Checkboxes & Radios
- Size `20px x 20px`, `6px` radius for checkboxes; circular for single-choice status selectors.
- Unchecked: `#FFFFFF` fill with `1.5px solid #D4DAD7`.
- Checked: `#173F36` fill with an inset `#FFFFFF` indicator check/dot.

### Cards & Data Panels
- **Standard Card**: `#FFFFFF` background, `20px` radius, `1px solid #E4E8E6` border, `24px` padding.
- **Deep Pine Focus Card**: `#173F36` surface, `#FFFFFF` display typography, amber `#F2C96C` accents for percentages and counts.
- **Amber Metric Banner**: `#FDF8ED` surface, `1px solid #F2C96C` border, `#7A5E12` body text.

### Attendance Roster Row
- Minimum row height of `60px` with `1px solid #E4E8E6` bottom divider.
- Student avatar (`36px` circle), student name in `14px` weight `600`, student ID in `12px` `#6E7A76`.
- Interactive multi-segment status selector integrated on the right for quick, one-click attendance marking. Hover state shifts row background to `#F8F9F8` over a `150ms` ease.